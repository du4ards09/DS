package Loja;

public class Nota {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
