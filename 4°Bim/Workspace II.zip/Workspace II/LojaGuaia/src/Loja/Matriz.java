package Loja;

public class Matriz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
