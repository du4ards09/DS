package Loja;

public class NumeroPositivo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
