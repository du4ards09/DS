package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.WindowConstants;

public class Menu extends JFrame {
	private static final long serialVersionUID = 1L;
	 
	public Menu() {
		
		Color CORFonte = new Color(79,79,79);
		Font FonteText = new Font("Verdana", Font.BOLD, 17);
		
		this.setSize(800, 600);
		this.setTitle("Menu");
		this.setLocationRelativeTo(null);
		this.setExtendedState(MAXIMIZED_BOTH);
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
		JMenu arq = new JMenu("Arquivo");
		JMenu cad = new JMenu("Cadastrar");
		/*JMenu visu = new JMenu("Visualizar");*/
		JMenu aju = new JMenu("Ajuda");
		
		JMenuItem sair = new JMenuItem("Sair");
		JMenuItem cat = new JMenuItem("Categoria");
		JMenuItem prod = new JMenuItem("Produto");
		/*JMenuItem cats = new JMenuItem("Categorias");
		JMenuItem prods = new JMenuItem("Produto");*/
		JMenuItem sobre = new JMenuItem("Sobre");
		
		arq.add(sair);
		cad.add(cat);
		cad.add(prod);
		/*visu.add(cats);
		visu.add(prods);*/
		aju.add(sobre);
		
		JMenuBar bar = new JMenuBar();
		setJMenuBar(bar);
		arq.setFont(FonteText);
		arq.setForeground(CORFonte);
		bar.add(arq);
		cad.setFont(FonteText);
		cad.setForeground(CORFonte);
		bar.add(cad);
		/*visu.setFont(FonteText);
		visu.setForeground(CORFonte);
		bar.add(visu);*/
		aju.setFont(FonteText);
		aju.setForeground(CORFonte);
		bar.add(aju);
		
		sair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		}	
		);
		cat.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Categoria ctg = new Categoria();
				ctg.setVisible(true);
				
			}
		}	
		);
		
		prod.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Produto prd = new Produto();
				prd.setVisible(true);
			}
		}	
		);
		
		
		/*visu.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Categorias cats = new Categorias();
				Produtos prods = new Produtos();
				cats.setVisible(true);
				prods.setVisible(true);
				
			}
		}	
		);*/
		
		sobre.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Sobre sbr = new Sobre();
				sbr.setVisible(true);
				
			}
		}	
		);
		
		this.setVisible(true);
		
	}

}
