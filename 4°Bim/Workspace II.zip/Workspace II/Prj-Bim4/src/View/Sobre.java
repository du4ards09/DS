package View;

//import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JDialog;
import javax.swing.ImageIcon;

public class Sobre extends JDialog{
	private static final long serialVersionUID = 1L;
	
	JLabel lbNome1, lbNome2, lbEmail1, lbEmail2, moldura, moldura2;
	ImageIcon imagem, imagem2;
	
	public Sobre() {
		
		this.setTitle("Etec De Guaianazes");
		this.setSize(800,600);
		this.setModal(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		//add(Imagem);
		ImageIcon imagem = new ImageIcon("src/View/Fotos/Anaju.png");
		JLabel moldura = new JLabel("", imagem, JLabel.CENTER);
		moldura.setBounds(20,10,200,200);
		add(moldura);
		
		ImageIcon imagem2 = new ImageIcon("src/View/Fotos/Madu.png");
		JLabel moldura2 = new JLabel("", imagem2, JLabel.CENTER);
		moldura2.setBounds(20,140,200,200);
		add(moldura2);
		
		this.setLayout(null);
	}
}
