package View;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Categoria extends JDialog {
	private static final long serialVersionUID = 1L;
	
	JLabel lbCategoria, lbEmpresa;
	JTextField txCategoria;
	JButton btSalvar;
	
	public Categoria() {
		
		Font FonteCat = new Font("Verdana", Font.BOLD, 15);
		Font FonteLogo = new Font("Verdana", Font.BOLD, 30);
		
		this.setTitle("Etec De Guaianazes");
		this.setSize(800,600);
		this.setModal(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		lbEmpresa = new JLabel();
		lbEmpresa.setBounds(220,10,400,75);
		lbEmpresa.setFont(FonteLogo);
		lbEmpresa.setText("Gerenciar Categorias");
		add(lbEmpresa);
		
		lbCategoria = new JLabel();
		lbCategoria.setBounds(300, 120, 100, 20);
		lbCategoria.setFont(FonteCat);
		lbCategoria.setText("Categoria: ");
		add(lbCategoria);
		
		txCategoria = new JTextField();
		txCategoria.setBounds(400, 120, 100, 20);
		add(txCategoria);
		
		btSalvar = new JButton();
		btSalvar.setBounds(400, 150, 100, 20);
		btSalvar.setText("Salvar");
		btSalvar.setBackground(Color.PINK);
		btSalvar.setForeground(Color.BLACK);
		add(btSalvar);
		
		btSalvar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
                String categoria;
                categoria = txCategoria.getText();
                txCategoria.setEditable(false);
                JOptionPane.showMessageDialog(null, "Categoria: " + categoria + " salva !");
            }
        });
		
		this.setLayout(null);
	}
}

