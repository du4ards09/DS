package View;

//import java.awt.Font;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Produto extends JDialog{
	private static final long serialVersionUID = 1L;
	
	JLabel lbProduto, lbValor, lbIdCategoria, lbDescricao, lbQtde;
	JTextField txProduto, txValor, txIdCategoria, txDescricao, txQtde;
	JButton btSalvar;
	
	public Produto() {
		
		Font FonteTitulo = new Font("Verdana", Font.BOLD, 14);
		Font FonteLogo = new Font("Verdana", Font.BOLD, 30);
		
		this.setTitle("Etec De Guaianazes");
		this.setSize(800,600);
		this.setModal(true);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		
		JLabel lbEmpresa = new JLabel();
		lbEmpresa.setBounds(240,10,400,75);
		lbEmpresa.setFont(FonteLogo);
		lbEmpresa.setText("Gerenciar Produtos");
		add(lbEmpresa);
		
		lbProduto = new JLabel();
		lbProduto.setBounds(280, 90, 100, 20);
		lbProduto.setFont(FonteTitulo);
		lbProduto.setText("Produto: ");
		add(lbProduto);
		
		txProduto = new JTextField();
		txProduto.setBounds(420, 90, 100, 20);
		add(txProduto);
		
		lbValor = new JLabel();
		lbValor.setBounds(280, 120, 100, 20);
		lbValor.setFont(FonteTitulo);
		lbValor.setText("Valor: ");
		add(lbValor);
		
		txValor = new JTextField();
		txValor.setBounds(420, 120, 100, 20);
		add(txValor);
		
		lbIdCategoria = new JLabel();
		lbIdCategoria.setBounds(280, 150, 100, 20);
		lbIdCategoria.setFont(FonteTitulo);
		lbIdCategoria.setText("IdCategoria: ");
		add(lbIdCategoria);
		
		txIdCategoria = new JTextField();
		txIdCategoria.setBounds(420, 150, 100, 20);
		add(txIdCategoria);
		
		lbDescricao = new JLabel();
		lbDescricao.setBounds(280, 180, 150, 20);
		lbDescricao.setFont(FonteTitulo);
		lbDescricao.setText("Descri��o do Produto ");
		add(lbDescricao);
		
		txDescricao = new JTextField();
		txDescricao.setBounds(420, 180, 100, 20);
		add(txDescricao);
		
		lbQtde = new JLabel();
		lbQtde.setBounds(280, 210, 100, 20);
		lbQtde.setFont(FonteTitulo);
		lbQtde.setText("Quantidade: ");
		add(lbQtde);
		
		txQtde = new JTextField();
		txQtde.setBounds(420, 210, 100, 20);
		add(txQtde);
		
		btSalvar = new JButton();
		btSalvar.setBounds(420, 250, 100, 40);
		btSalvar.setText("Salvar");
		btSalvar.setBackground(Color.PINK);
		btSalvar.setForeground(Color.BLACK);
		add(btSalvar);
		
		btSalvar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
                String produto,valor, idCategoria, descricao, qtde;
                
	        	produto = txProduto.getText();
	        	valor = txValor.getText();
	        	idCategoria = txIdCategoria.getText();
	        	descricao = txDescricao.getText();
	        	qtde = txQtde.getText();
	
	        	JOptionPane.showMessageDialog(null, "Produto: " +produto +"\nValor: "+valor+"\nId Categoria: "+idCategoria+"\nDescricao: "+ descricao+"\nQuantidade: "+qtde);
            }
        });
		
		this.setLayout(null);
	}
}
