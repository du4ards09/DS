/**
 * 
 */
/**
 * 
 */
module ConexaoBd {
	requires java.desktop;
	requires java.sql;
	requires mysql.connector.java;
}