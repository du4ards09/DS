package View;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JTextField;
import com.mysql.jdbc.Statement;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class Categoria extends JDialog {
	private static final long serialVersionUID = 1L;
	
	JLabel lbCategoria,lbIdCategoria, lbEmpresa;
	JTextField txCategoria, txIdCategoria;
	JButton btAlterar,btExcluir,btInserir;
	
	public Categoria() {
		
		Font FonteCat = new Font("Verdana", Font.BOLD, 15);
		Font FonteLogo = new Font("Verdana", Font.BOLD, 30);
		Color CORBotao = new Color(135,206,235);
		Color CORFundo = new Color(70,130,180);
		Color CORFonte = new Color(245,255,250);
		Color CORFonteBotao = new Color(70,130,180);
		
		this.setTitle("Etec De Guaianazes");
		this.setSize(800,600);
		this.setModal(true);
		this.setLocationRelativeTo(null);
		this.getContentPane().setBackground(CORFundo);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		lbEmpresa = new JLabel();
		lbEmpresa.setBounds(220,60,400,75);
		lbEmpresa.setFont(FonteLogo);
		lbEmpresa.setForeground(CORFonte);
		lbEmpresa.setText("Gerenciar Categorias");
		add(lbEmpresa);
		
		lbCategoria = new JLabel();
		lbCategoria.setBounds(280, 160, 100, 20);
		lbCategoria.setFont(FonteCat);
		lbCategoria.setForeground(CORFonte);
		lbCategoria.setText("Categoria: ");
		add(lbCategoria);
		
		txCategoria = new JTextField();
		txCategoria.setBounds(400, 160, 140, 25);
		add(txCategoria);
		
		btInserir = new JButton();
		btInserir.setBounds(240, 240, 100, 20);
		btInserir.setText("Inserir");
		btInserir.setBackground(CORBotao);
		btInserir.setForeground(CORFonteBotao);
		add(btInserir);
		
		btAlterar = new JButton();
		btAlterar.setBounds(360, 240, 100, 20);
		btAlterar.setText("Alterar");
		btAlterar.setBackground(CORBotao);
		btAlterar.setForeground(CORFonteBotao);
		add(btAlterar);
		
		btExcluir = new JButton();
		btExcluir.setBounds(480, 240, 100, 20);
		btExcluir.setText("Excluir");
		btExcluir.setBackground(CORBotao);
		btExcluir.setForeground(CORFonteBotao);
		add(btExcluir);
		
		btInserir.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		//controla e executa uma instru�ao sql
        		Statement state;
        			
        	
        		//instancia o objeto conex da classe Conexao
        		Conexao conex = new Conexao();     
        	
        		String sql = "insert into tbCategoria values(null, '"+txCategoria.getText()+"')";
        	
        					
        		conex.conectar();      
        					
        		try{                  
        				
        			state = (Statement) Conexao.con.createStatement();
        			state.executeUpdate(sql);
        			JOptionPane.showMessageDialog(null, "Categoria: " + txCategoria.getText() + " salva !");	                       
        		}
        		catch(SQLException erro){
        			JOptionPane.showMessageDialog(null,"Nao foi possível realizar a inserção!");
        		}     
        			
        		conex.desconectar();
        		 
            }
        });
		
		btExcluir.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		//controla e executa uma instru�ao sql
        		Statement state;
        			
        	
        		//instancia o objeto conex da classe Conexao
        		Conexao conex = new Conexao();     
        		
        		String sql = "delete from tbCategoria where idCategoria =  ";
        	
        					
        		conex.conectar();      
        					
        		try{                  
        				
        			state = (Statement) Conexao.con.createStatement();
        			state.executeUpdate(sql);
        			JOptionPane.showMessageDialog(null, "Categoria: " + txCategoria.getText() + " deletada !");	                       
        		}
        		catch(SQLException erro){
        			JOptionPane.showMessageDialog(null,"Nao foi possível realizar o delete!");
        		}     
        			
        		conex.desconectar();   
            }
        });
		
		this.setLayout(null);
	}
}


