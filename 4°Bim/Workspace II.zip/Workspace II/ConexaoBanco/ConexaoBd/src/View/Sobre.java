package View;

import javax.swing.JLabel;
import javax.swing.JDialog;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;

public class Sobre extends JDialog{
	private static final long serialVersionUID = 1L;
	
	JLabel lbNome1, lbNome2, lbEmail1, lbEmail2, moldura, moldura2;
	ImageIcon imagem, imagem2;
	
	public Sobre() {
		
		Font FonteCat = new Font("Verdana", Font.BOLD, 15);
		Font FonteLogo = new Font("Verdana", Font.BOLD, 30);
		Color CORBotao = new Color(135,206,235);
		Color CORFundo = new Color(70,130,180);
		Color CORFonte = new Color(245,255,250);
		Color CORFonteBotao = new Color(70,130,180);
		
		this.setTitle("Etec De Guaianazes");
		this.setSize(800,600);
		this.setModal(true);
		this.setLocationRelativeTo(null);
		this.getContentPane().setBackground(CORFundo);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		//add(Imagem);
		ImageIcon imagem = new ImageIcon("src/Fotos/Anaju.png");
		JLabel moldura = new JLabel("", imagem, JLabel.CENTER);
		moldura.setBounds(20,50,200,200);
		add(moldura);
		
		lbNome1 = new JLabel();
		lbNome1.setBounds(220,110,400,75);
		lbNome1.setFont(FonteLogo);
		lbNome1.setForeground(CORFonte);
		lbNome1.setText("Ana Júlia Lima");
		add(lbNome1);
		
		lbNome1 = new JLabel();
		lbNome1.setBounds(220,140,400,75);
		lbNome1.setForeground(CORFonte);
		lbNome1.setText("email");
		add(lbNome1);
		
		ImageIcon imagem2 = new ImageIcon("src/Fotos/Madu.png");
		JLabel moldura2 = new JLabel("", imagem2, JLabel.CENTER);
		moldura2.setBounds(20,200,200,200);
		add(moldura2);
		
		lbNome2 = new JLabel();
		lbNome2.setBounds(220,260,400,75);
		lbNome2.setFont(FonteLogo);
		lbNome2.setForeground(CORFonte);
		lbNome2.setText("Maria Eduarda Lima");
		add(lbNome2);
		
		lbNome2 = new JLabel();
		lbNome2.setBounds(220,290,400,75);
		lbNome2.setForeground(CORFonte);
		lbNome2.setText("email: mariaeduardaaraujodelima1@gmail.com");
		add(lbNome2);
		
		this.setLayout(null);
	}
}
