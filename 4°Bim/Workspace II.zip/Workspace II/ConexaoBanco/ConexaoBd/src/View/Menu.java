package View;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.WindowConstants;

public class Menu extends JFrame {
	private static final long serialVersionUID = 1L;
	 
	public Menu() {
		
		Color CORFonte = new Color(79,79,79) ;
		Color CORFundo = new Color(173,216,230);
		Color CORFundo2 = new Color (135,206,235);
		Font FonteText = new Font("Verdana", Font.BOLD, 17);
		
		this.setSize(800, 600);
		this.setTitle("Menu");
		this.setLocationRelativeTo(null);
		this.setExtendedState(MAXIMIZED_BOTH);
		this.getContentPane().setBackground(CORFundo2);
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
		JMenu arq = new JMenu("Arquivo");
		JMenu cad = new JMenu("Cadastrar");
		JMenu aju = new JMenu("Ajuda");
		/*JMenu visu = new JMenu("Visualizar");*/
		
		JMenuItem sair = new JMenuItem("Sair");
		JMenuItem cat = new JMenuItem("Categoria");
		JMenuItem prod = new JMenuItem("Produto");
		JMenuItem sobre = new JMenuItem("Sobre");
		/*JMenuItem cats = new JMenuItem("Categorias");
		JMenuItem prods = new JMenuItem("Produto");*/
		
		arq.add(sair);
		cad.add(cat);
		cad.add(prod);
		aju.add(sobre);
		/*visu.add(cats);
		visu.add(prods);*/
		
		JMenuBar bar = new JMenuBar();
		bar.setBackground(CORFundo);
		setJMenuBar(bar);
		
		arq.setFont(FonteText);
		arq.setForeground(CORFonte);
		bar.add(arq);
		
		cad.setFont(FonteText);
		cad.setForeground(CORFonte);
		bar.add(cad);
		
		aju.setFont(FonteText);
		aju.setForeground(CORFonte);
		bar.add(aju);
		/*visu.setFont(FonteText);
		visu.setForeground(CORFonte);
		bar.add(visu);*/
		
		sair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		}	
		);
		cat.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Categoria ctg = new Categoria();
				ctg.setVisible(true);
				
			}
		}	
		);
		
		prod.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Produto prd = new Produto();
				prd.setVisible(true);
			}
		}	
		);
		
		
		/*visu.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Categorias cats = new Categorias();
				Produtos prods = new Produtos();
				cats.setVisible(true);
				prods.setVisible(true);
				
			}
		}	
		);*/
		
		sobre.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Sobre sbr = new Sobre();
				sbr.setVisible(true);
				
			}
		}	
		);
		
		this.setVisible(true);
		
	}

}

