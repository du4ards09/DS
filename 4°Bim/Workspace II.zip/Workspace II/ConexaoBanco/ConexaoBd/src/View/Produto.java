package View;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JDialog;
import javax.swing.JButton;
import javax.swing.JTextField;
import com.mysql.jdbc.Statement;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class Produto extends JDialog{
	private static final long serialVersionUID = 1L;
	
	JLabel lbProduto, lbValor, lbIdCategoria, lbDescricao, lbQtde;
	JTextField txProduto, txValor, txIdCategoria, txDescricao, txQtde;
	JButton btSalvar;
	
	public Produto() {
		
		Font FonteTitulo = new Font("Verdana", Font.BOLD, 14);
		Font FonteLogo = new Font("Verdana", Font.BOLD, 30);
		Color CORFundo = new Color(70,130,180);
		Color CORFonte = new Color(245,255,250);
		Color CORBotao = new Color(135,206,235);
		Color CORFonteBotao = new Color(70,130,180);
		
		this.setTitle("Etec De Guaianazes");
		this.setSize(800,600);
		this.setModal(true);
		this.setLocationRelativeTo(null);
		this.getContentPane().setBackground(CORFundo);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		
		JLabel lbEmpresa = new JLabel();
		lbEmpresa.setBounds(240,50,400,75);
		lbEmpresa.setFont(FonteLogo);
		lbEmpresa.setForeground(CORFonte);
		lbEmpresa.setText("Gerenciar Produtos");
		add(lbEmpresa);
		
		lbProduto = new JLabel();
		lbProduto.setBounds(260, 150, 100, 20);
		lbProduto.setFont(FonteTitulo);
		lbProduto.setForeground(CORFonte);
		lbProduto.setText("Produto: ");
		add(lbProduto);
		
		txProduto = new JTextField();
		txProduto.setBounds(460, 150, 100, 20);
		add(txProduto);
		
		lbValor = new JLabel();
		lbValor.setBounds(260, 190, 100, 20);
		lbValor.setFont(FonteTitulo);
		lbValor.setForeground(CORFonte);
		lbValor.setText("Valor: ");
		add(lbValor);
		
		txValor = new JTextField();
		txValor.setBounds(460, 190, 100, 20);
		add(txValor);
		
		lbIdCategoria = new JLabel();
		lbIdCategoria.setBounds(260, 230, 160, 20);
		lbIdCategoria.setFont(FonteTitulo);
		lbIdCategoria.setForeground(CORFonte);
		lbIdCategoria.setText("IdCategoria: ");
		add(lbIdCategoria);
		
		txIdCategoria = new JTextField();
		txIdCategoria.setBounds(460, 230, 100, 20);
		add(txIdCategoria);
		
		lbDescricao = new JLabel();
		lbDescricao.setBounds(260, 270, 180, 20);
		lbDescricao.setFont(FonteTitulo);
		lbDescricao.setForeground(CORFonte);
		lbDescricao.setText("Descrição do Produto: ");
		add(lbDescricao);
		
		txDescricao = new JTextField();
		txDescricao.setBounds(460, 270, 100, 20);
		add(txDescricao);
		
		lbQtde = new JLabel();
		lbQtde.setBounds(260, 310, 100, 20);
		lbQtde.setFont(FonteTitulo);
		lbQtde.setForeground(CORFonte);
		lbQtde.setText("Quantidade: ");
		add(lbQtde);
		
		txQtde = new JTextField();
		txQtde.setBounds(460, 310, 100, 20);
		add(txQtde);
		
		btSalvar = new JButton();
		btSalvar.setBounds(460, 350,100, 20);
		btSalvar.setText("Salvar");
		btSalvar.setBackground(CORBotao);
		btSalvar.setForeground(CORFonteBotao);
		add(btSalvar);
		
		btSalvar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		//controla e executa uma instrução sql
        		Statement state;
        			
        	
        		//instancia o objeto conex da classe Conexao
        		Conexao conex = new Conexao();     
        	
        		String sql = "insert into tbProduto values(null, '"+txProduto.getText()+"','"+txIdCategoria.getText()+"','"+txValor.getText()+"','"+txDescricao.getText()+"','"+txQtde.getText()+"') where idCategoria = '"+txIdCategoria.getText()+"' )";
        		 
        		int idC = Integer.parseInt(txIdCategoria.getText());
        		double valor = Double.parseDouble(txValor.getText());
        		int qtde = Integer.parseInt(txQtde.getText());
        		
        		
        					
        		conex.conectar();      
        					
        		try{                  
        				
        			state = (Statement) Conexao.con.createStatement();
        			state.executeUpdate(sql);
        			JOptionPane.showMessageDialog(null, "Produto: " + txProduto.getText() + " salvo !");	                       
        		}
        		catch(SQLException erro){
        			JOptionPane.showMessageDialog(null,"Nao foi possível realizar a inserção!");
        		}     
        			
        		conex.desconectar();
        		
            }
        });
		
		this.setLayout(null);
	}
}

